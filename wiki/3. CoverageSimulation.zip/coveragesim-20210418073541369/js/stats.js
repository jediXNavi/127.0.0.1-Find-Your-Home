var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "20",
        "ok": "20",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "694",
        "ok": "694",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2250",
        "ok": "2250",
        "ko": "-"
    },
    "percentiles1": {
        "total": "138",
        "ok": "138",
        "ko": "-"
    },
    "percentiles2": {
        "total": "225",
        "ok": "225",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1014",
        "ok": "1014",
        "ko": "-"
    },
    "percentiles4": {
        "total": "8596",
        "ok": "8596",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 19,
    "percentage": 95
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.244",
        "ok": "0.244",
        "ko": "-"
    }
},
contents: {
"req_createlandlord-9fe00": {
        type: "REQUEST",
        name: "CreateLandlord",
path: "CreateLandlord",
pathFormatted: "req_createlandlord-9fe00",
stats: {
    "name": "CreateLandlord",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles2": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles3": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "percentiles4": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_loginlandlord-fcebc": {
        type: "REQUEST",
        name: "LoginLandlord",
path: "LoginLandlord",
pathFormatted: "req_loginlandlord-fcebc",
stats: {
    "name": "LoginLandlord",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "percentiles2": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "percentiles3": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "percentiles4": {
        "total": "109",
        "ok": "109",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_updatelandlord-af2cc": {
        type: "REQUEST",
        name: "UpdateLandlord",
path: "UpdateLandlord",
pathFormatted: "req_updatelandlord-af2cc",
stats: {
    "name": "UpdateLandlord",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "percentiles2": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "percentiles3": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "percentiles4": {
        "total": "105",
        "ok": "105",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_createproperty-d3fc9": {
        type: "REQUEST",
        name: "CreateProperty",
path: "CreateProperty",
pathFormatted: "req_createproperty-d3fc9",
stats: {
    "name": "CreateProperty",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "percentiles4": {
        "total": "10491",
        "ok": "10491",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_createtenant-57e1e": {
        type: "REQUEST",
        name: "CreateTenant",
path: "CreateTenant",
pathFormatted: "req_createtenant-57e1e",
stats: {
    "name": "CreateTenant",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "percentiles2": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "percentiles3": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "percentiles4": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_logintenant-d821d": {
        type: "REQUEST",
        name: "LoginTenant",
path: "LoginTenant",
pathFormatted: "req_logintenant-d821d",
stats: {
    "name": "LoginTenant",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles2": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles3": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles4": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_updatetenant-0c6dd": {
        type: "REQUEST",
        name: "UpdateTenant",
path: "UpdateTenant",
pathFormatted: "req_updatetenant-0c6dd",
stats: {
    "name": "UpdateTenant",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "percentiles2": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "percentiles3": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "percentiles4": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_searchpropertie-214c9": {
        type: "REQUEST",
        name: "SearchProperties",
path: "SearchProperties",
pathFormatted: "req_searchpropertie-214c9",
stats: {
    "name": "SearchProperties",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "percentiles2": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "percentiles3": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "percentiles4": {
        "total": "182",
        "ok": "182",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_viewpropertydet-e80c3": {
        type: "REQUEST",
        name: "ViewPropertyDetails",
path: "ViewPropertyDetails",
pathFormatted: "req_viewpropertydet-e80c3",
stats: {
    "name": "ViewPropertyDetails",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "percentiles2": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "percentiles3": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "percentiles4": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_tenantpropappli-143bf": {
        type: "REQUEST",
        name: "TenantPropApplication",
path: "TenantPropApplication",
pathFormatted: "req_tenantpropappli-143bf",
stats: {
    "name": "TenantPropApplication",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "percentiles2": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "percentiles3": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "percentiles4": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_listlandlordpro-e7d14": {
        type: "REQUEST",
        name: "ListLandlordProperty",
path: "ListLandlordProperty",
pathFormatted: "req_listlandlordpro-e7d14",
stats: {
    "name": "ListLandlordProperty",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "percentiles2": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "percentiles3": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "percentiles4": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_tenantcreateser-35a49": {
        type: "REQUEST",
        name: "TenantCreateServiceRequest",
path: "TenantCreateServiceRequest",
pathFormatted: "req_tenantcreateser-35a49",
stats: {
    "name": "TenantCreateServiceRequest",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "percentiles2": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "percentiles3": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "percentiles4": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_tenantupdateser-0fc75": {
        type: "REQUEST",
        name: "TenantUpdateServiceRequest",
path: "TenantUpdateServiceRequest",
pathFormatted: "req_tenantupdateser-0fc75",
stats: {
    "name": "TenantUpdateServiceRequest",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "percentiles2": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "percentiles3": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "percentiles4": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_viewlandlordser-a7b39": {
        type: "REQUEST",
        name: "ViewLandlordServiceRequest",
path: "ViewLandlordServiceRequest",
pathFormatted: "req_viewlandlordser-a7b39",
stats: {
    "name": "ViewLandlordServiceRequest",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "percentiles2": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "percentiles3": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "percentiles4": {
        "total": "515",
        "ok": "515",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_resolveservicer-6462b": {
        type: "REQUEST",
        name: "ResolveServiceRequest",
path: "ResolveServiceRequest",
pathFormatted: "req_resolveservicer-6462b",
stats: {
    "name": "ResolveServiceRequest",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "percentiles2": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "percentiles3": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "percentiles4": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_deletelandlordp-f9c80": {
        type: "REQUEST",
        name: "DeleteLandlordProperty",
path: "DeleteLandlordProperty",
pathFormatted: "req_deletelandlordp-f9c80",
stats: {
    "name": "DeleteLandlordProperty",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "percentiles2": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "percentiles3": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "percentiles4": {
        "total": "181",
        "ok": "181",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_logouttenant-62bde": {
        type: "REQUEST",
        name: "LogoutTenant",
path: "LogoutTenant",
pathFormatted: "req_logouttenant-62bde",
stats: {
    "name": "LogoutTenant",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "percentiles2": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "percentiles3": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "percentiles4": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_logoutlandlord-fea3a": {
        type: "REQUEST",
        name: "LogoutLandlord",
path: "LogoutLandlord",
pathFormatted: "req_logoutlandlord-fea3a",
stats: {
    "name": "LogoutLandlord",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "percentiles2": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "percentiles3": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "percentiles4": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_deletelandlorda-90bfc": {
        type: "REQUEST",
        name: "DeleteLandlordAccount",
path: "DeleteLandlordAccount",
pathFormatted: "req_deletelandlorda-90bfc",
stats: {
    "name": "DeleteLandlordAccount",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles2": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles3": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles4": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    },"req_deletetenantacc-54566": {
        type: "REQUEST",
        name: "DeleteTenantAccount",
path: "DeleteTenantAccount",
pathFormatted: "req_deletetenantacc-54566",
stats: {
    "name": "DeleteTenantAccount",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "percentiles2": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "percentiles3": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "percentiles4": {
        "total": "104",
        "ok": "104",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.012",
        "ok": "0.012",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
