var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "10570",
        "ok": "10568",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "59666",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "1017",
        "ok": "1006",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "3844",
        "ok": "3758",
        "ko": "1"
    },
    "percentiles1": {
        "total": "122",
        "ok": "122",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "243",
        "ok": "243",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "3869",
        "ok": "3865",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "21870",
        "ok": "18985",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9068,
    "percentage": 86
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 217,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1283,
    "percentage": 12
},
    "group4": {
    "name": "failed",
    "count": 2,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.478",
        "ok": "2.477",
        "ko": "0"
    }
},
contents: {
"req_logintenant-d821d": {
        type: "REQUEST",
        name: "LoginTenant",
path: "LoginTenant",
pathFormatted: "req_logintenant-d821d",
stats: {
    "name": "LoginTenant",
    "numberOfRequests": {
        "total": "3526",
        "ok": "3526",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "99",
        "ok": "99",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "41121",
        "ok": "41121",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "795",
        "ok": "795",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1919",
        "ok": "1919",
        "ko": "-"
    },
    "percentiles1": {
        "total": "144",
        "ok": "144",
        "ko": "-"
    },
    "percentiles2": {
        "total": "547",
        "ok": "547",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3718",
        "ok": "3718",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7585",
        "ok": "7585",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2807,
    "percentage": 80
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 149,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 570,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.827",
        "ok": "0.827",
        "ko": "-"
    }
}
    },"req_tenantcreateser-35a49": {
        type: "REQUEST",
        name: "TenantCreateServiceRequest",
path: "TenantCreateServiceRequest",
pathFormatted: "req_tenantcreateser-35a49",
stats: {
    "name": "TenantCreateServiceRequest",
    "numberOfRequests": {
        "total": "3522",
        "ok": "3520",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "109",
        "ok": "109",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "59666",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "2108",
        "ok": "2075",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "6093",
        "ok": "5936",
        "ko": "1"
    },
    "percentiles1": {
        "total": "144",
        "ok": "144",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "455",
        "ok": "453",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "13475",
        "ok": "13474",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "30116",
        "ok": "29856",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2796,
    "percentage": 79
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 58,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 666,
    "percentage": 19
},
    "group4": {
    "name": "failed",
    "count": 2,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.826",
        "ok": "0.825",
        "ko": "0"
    }
}
    },"req_logouttenant-62bde": {
        type: "REQUEST",
        name: "LogoutTenant",
path: "LogoutTenant",
pathFormatted: "req_logouttenant-62bde",
stats: {
    "name": "LogoutTenant",
    "numberOfRequests": {
        "total": "3522",
        "ok": "3522",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "40702",
        "ok": "40702",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1244",
        "ok": "1244",
        "ko": "-"
    },
    "percentiles1": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "percentiles2": {
        "total": "35",
        "ok": "35",
        "ko": "-"
    },
    "percentiles3": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2004",
        "ok": "2004",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3465,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 10,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 47,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.826",
        "ok": "0.826",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
