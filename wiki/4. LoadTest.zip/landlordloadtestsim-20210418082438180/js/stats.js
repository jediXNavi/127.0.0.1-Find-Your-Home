var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "15245",
        "ok": "15237",
        "ko": "8"
    },
    "minResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "10001"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "59446",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "1890",
        "ok": "1872",
        "ko": "36990"
    },
    "standardDeviation": {
        "total": "5290",
        "ok": "5213",
        "ko": "18570"
    },
    "percentiles1": {
        "total": "346",
        "ok": "346",
        "ko": "26621"
    },
    "percentiles2": {
        "total": "823",
        "ok": "821",
        "ko": "60000"
    },
    "percentiles3": {
        "total": "7713",
        "ok": "7647",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "27735",
        "ok": "27706",
        "ko": "60000"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11377,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 693,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3167,
    "percentage": 21
},
    "group4": {
    "name": "failed",
    "count": 8,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.457",
        "ok": "3.455",
        "ko": "0.002"
    }
},
contents: {
"req_loginlandlord-fcebc": {
        type: "REQUEST",
        name: "LoginLandlord",
path: "LoginLandlord",
pathFormatted: "req_loginlandlord-fcebc",
stats: {
    "name": "LoginLandlord",
    "numberOfRequests": {
        "total": "6960",
        "ok": "6958",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "105",
        "ok": "105",
        "ko": "10001"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "30745",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "798",
        "ok": "788",
        "ko": "35001"
    },
    "standardDeviation": {
        "total": "2024",
        "ok": "1892",
        "ko": "25000"
    },
    "percentiles1": {
        "total": "239",
        "ok": "239",
        "ko": "35001"
    },
    "percentiles2": {
        "total": "421",
        "ok": "420",
        "ko": "47500"
    },
    "percentiles3": {
        "total": "3782",
        "ok": "3781",
        "ko": "57500"
    },
    "percentiles4": {
        "total": "7162",
        "ok": "7158",
        "ko": "59500"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5700,
    "percentage": 82
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 207,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1051,
    "percentage": 15
},
    "group4": {
    "name": "failed",
    "count": 2,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.578",
        "ok": "1.578",
        "ko": "0"
    }
}
    },"req_createproperty-d3fc9": {
        type: "REQUEST",
        name: "CreateProperty",
path: "CreateProperty",
pathFormatted: "req_createproperty-d3fc9",
stats: {
    "name": "CreateProperty",
    "numberOfRequests": {
        "total": "1329",
        "ok": "1329",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "442",
        "ok": "442",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "43030",
        "ok": "43030",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12307",
        "ok": "12307",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12297",
        "ok": "12297",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4706",
        "ok": "4706",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27308",
        "ok": "27308",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29148",
        "ok": "29148",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31647",
        "ok": "31647",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 242,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 155,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 932,
    "percentage": 70
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.301",
        "ok": "0.301",
        "ko": "-"
    }
}
    },"req_listlandlordpro-e7d14": {
        type: "REQUEST",
        name: "ListLandlordProperty",
path: "ListLandlordProperty",
pathFormatted: "req_listlandlordpro-e7d14",
stats: {
    "name": "ListLandlordProperty",
    "numberOfRequests": {
        "total": "5627",
        "ok": "5621",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "209",
        "ok": "209",
        "ko": "26328"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "59446",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "1204",
        "ok": "1165",
        "ko": "37653"
    },
    "standardDeviation": {
        "total": "2576",
        "ok": "2227",
        "ko": "15802"
    },
    "percentiles1": {
        "total": "464",
        "ok": "464",
        "ko": "26621"
    },
    "percentiles2": {
        "total": "875",
        "ok": "870",
        "ko": "51697"
    },
    "percentiles3": {
        "total": "4124",
        "ok": "4117",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "10042",
        "ok": "8921",
        "ko": "60000"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4126,
    "percentage": 73
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 326,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1169,
    "percentage": 21
},
    "group4": {
    "name": "failed",
    "count": 6,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.276",
        "ok": "1.275",
        "ko": "0.001"
    }
}
    },"req_logoutlandlord-fea3a": {
        type: "REQUEST",
        name: "LogoutLandlord",
path: "LogoutLandlord",
pathFormatted: "req_logoutlandlord-fea3a",
stats: {
    "name": "LogoutLandlord",
    "numberOfRequests": {
        "total": "1329",
        "ok": "1329",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8969",
        "ok": "8969",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "98",
        "ok": "98",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "548",
        "ok": "548",
        "ko": "-"
    },
    "percentiles1": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "percentiles2": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "percentiles3": {
        "total": "155",
        "ok": "155",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1723",
        "ok": "1723",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1309,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 15,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.301",
        "ok": "0.301",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
